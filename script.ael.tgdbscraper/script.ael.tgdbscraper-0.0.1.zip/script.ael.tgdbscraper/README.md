# TGDB scraper for Advanced Emulator Launcher
TGDB metadata and asset scraper for AEL
