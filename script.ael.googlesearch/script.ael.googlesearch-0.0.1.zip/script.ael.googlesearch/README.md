# script.ael.googlesearch
Googlesearch asset scraping plugin for AEL
