# script.ael.steam
Steam Library scanner and launcher for AEL
