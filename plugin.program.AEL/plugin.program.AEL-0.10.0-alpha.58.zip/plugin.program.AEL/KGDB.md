## Kodi games database

A design for the Kodi games database. When this document is finished I will post it in the Kodi forum.

Get inspiration from the Kodi Music Database in the Kodi Wiki.

### References

