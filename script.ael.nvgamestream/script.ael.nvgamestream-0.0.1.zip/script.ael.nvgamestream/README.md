# script.ael.nvgamestream
Nvidia Gamestream plugin for AEL
