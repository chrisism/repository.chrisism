## Current
- Minor bugfixes
- Updated dependency  

## Previous: v1.0.0
- The initial release of the new AKL fork.