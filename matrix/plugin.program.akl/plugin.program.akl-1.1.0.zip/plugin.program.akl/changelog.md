## Current
- Virtual categories now render items from database
- Add and execute single instance ROMs or Games
- Added an overview option with installed plugins
- Fix adding tags to ROMs
- Minor bugfixes
- Updated dependency  

## Previous: v1.0.0
- The initial release of the new AKL fork.