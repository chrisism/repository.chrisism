# Advanced Kodi Launcher Module
## script.module.akl

Main module for all Advanced Kodi Launcher applications and plugins.
