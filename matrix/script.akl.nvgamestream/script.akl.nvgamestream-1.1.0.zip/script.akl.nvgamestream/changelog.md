## Current
- Added support for Sunshine gamestream server
## Previous
- Added more system data from scanning
- Certificate and pairing tools now available as pip module