## Current
- New addon command and args support
- Added support for Moonlight-QT
- Updated to new module (sources)

## Previous
- Added support for Sunshine gamestream server
- Added more system data from scanning
- Certificate and pairing tools now available as pip module