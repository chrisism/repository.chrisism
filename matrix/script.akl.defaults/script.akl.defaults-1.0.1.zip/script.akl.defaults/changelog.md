## Current
- Updated to programs based file browser.
- Added joystick suspend option.
- Minor bugfixes.
- Updated dependency to newer version of module and AKL.

## Previous: v1.0.0
- First official release of this collection of default plugins for AKL.