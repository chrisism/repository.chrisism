## Current
- Added direct file launcher
- Supporting new source types
- Updated to programs based file browser.

## Previous
- Added joystick suspend option.
- Minor bugfixes.