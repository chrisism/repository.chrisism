## Current
- Fixed change file application for launcher.

## Previous
- Updated to programs based file browser.
- Added joystick suspend option.
- Minor bugfixes.
- Updated dependency to newer version of module and AKL.