## Current
- Updated dependencies
- Fix for nplayers metadata
## Previous
- Initial release of the MobyGames AKL plugin