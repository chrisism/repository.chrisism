## Current
- Fix with httpss prefix in urls
- Update for new module
- Added asset 'manual'
- Added PEGI rating
## Previous
- Updated dependencies
- Fix for nplayers metadata
