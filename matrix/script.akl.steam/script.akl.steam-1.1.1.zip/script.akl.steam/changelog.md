## Current
- Added support for new sources
- Added scraper

## Previous
First official release of this Steam plugin for AKL.