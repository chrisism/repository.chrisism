## Current
- Added support for trailers
- Fix for ESRB ratings
- Updated dependencies

## Previous
- The initial release of TGDB plugin for the AKL fork.