## Current
- New addon command and args parsing
- Support for new module (sources)
- Added update/refresh settings command

## Previous
- Added support for trailers
- Fix for ESRB ratings
- Updated dependencies