## Current
- Support for new sources
- Fixed scraping by using Google API engine
- Added Youtube support

## Previous
First official release of this Google search plugin for AKL.