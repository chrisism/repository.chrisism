# script.ael.defaults
Default launchers, scanners and scrapers for AEL
