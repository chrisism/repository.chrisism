﻿# -*- coding: utf-8 -*-
#
# Default plugins for AEL
# Launchers, scrapers and scanners
#
# --- Python standard library ---
from __future__ import unicode_literals
from __future__ import division

import sys
import argparse
import logging
import json
    
# ---------------------------------------------------------------------------------------------
# This is the plugin entry point.
# ---------------------------------------------------------------------------------------------
def run_plugin():
    # --- Some debug stuff for development ---
    print('------------ Called Advanced Emulator Launcher Plugin: Default plugins ------------')
    print('sys.platform     "{}"'.format(sys.platform))
    for i in range(len(sys.argv)): print('sys.argv[{}] "{}"'.format(i, sys.argv[i]))
    
    print('TEST A')
    parser = argparse.ArgumentParser(prog='script.ael.defaults')
    parser.add_argument('--cmd', help="Command to execute", choices=['launch', 'scan', 'scrape', 'configure'])
    parser.add_argument('--type',help="Plugin type", choices=['LAUNCHER', 'SCANNER', 'SCRAPER'], default='LAUNCHER')
    parser.add_argument('--romcollection_id', type=str, help="ROM Collection ID")
    parser.add_argument('--rom_id', type=str, help="ROM ID")
    parser.add_argument('--launcher_id', type=str, help="Launcher configuration ID")
    parser.add_argument('--rom', type=str, help="ROM data dictionary")
    parser.add_argument('--rom_args', type=str)
    parser.add_argument('--settings', type=str)
    parser.add_argument('--is_non_blocking', type=bool, default=False)
    
    print('TEST B')
    try:
        args = parser.parse_args()
        print('TEST C')
    except Exception as ex:
        print('Exception in plugin', exc_info=ex)
        print(parser.usage)
        return
    
    print('TEST D')
    if   args.type == 'LAUNCHER' and args.cmd == 'launch': launch_rom(args)
    elif args.type == 'LAUNCHER' and args.cmd == 'configure': configure_launcher(args)
    elif args.type == 'SCANNER'  and args.cmd == 'scan': scan_for_roms(args)
    elif args.type == 'SCANNER'  and args.cmd == 'configure': configure_scanner(args)
    elif args.type == 'SCRAPER'  and args.cmd == 'scrape': run_scraper(args)
    else:
        print(parser.format_help())
    
    print('Advanced Emulator Launcher Plugin: Default plugins -> exit')

# ---------------------------------------------------------------------------------------------
# Launcher methods.
# ---------------------------------------------------------------------------------------------
def launch_rom(args):
    print('App Launcher: Starting ...')

def configure_launcher(args):
    print('App Launcher: Configuring ...')

# ---------------------------------------------------------------------------------------------
# Scanner methods.
# ---------------------------------------------------------------------------------------------
def scan_for_roms(args):
    print('ROM Folder scanner: Starting scan ...')

def configure_scanner(args):
    print('ROM Folder scanner: Configuring ...')

# ---------------------------------------------------------------------------------------------
# Scraper methods.
# ---------------------------------------------------------------------------------------------
def run_scraper(args):
    print('Offline scraper: Starting ...')

        
# ---------------------------------------------------------------------------------------------
# RUN
# ---------------------------------------------------------------------------------------------
try:
    run_plugin()
except Exception as ex:
    print('Exception in plugin', exc_info=ex)
    