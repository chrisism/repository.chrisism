# script.ael.arcadedb
ArcadeDB scraper plugin for AEL
