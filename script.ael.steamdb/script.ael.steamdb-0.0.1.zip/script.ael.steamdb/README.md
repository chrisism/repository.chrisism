# script.ael.steamdb
SteamDB scraper plugin for AEL
