# script.ael.screenscraper
Screenscraper plugin for AEL
